<?php

namespace WellnessLiving\Core\Passport\Login\SignOut;

use WellnessLiving\WlModelAbstract;

/**
 * Signs user out.
 */
class SignOutModel extends WlModelAbstract
{
  }

?>