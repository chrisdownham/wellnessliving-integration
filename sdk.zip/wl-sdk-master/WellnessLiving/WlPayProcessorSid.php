<?php

namespace WellnessLiving;

/**
 * @deprecated As of 2023-09-11.
 *
 * Use class {@link \WellnessLiving\Wl\WlPayProcessorSid} instead.
 */
class WlPayProcessorSid extends \WellnessLiving\Wl\WlPayProcessorSid
{
}

?>