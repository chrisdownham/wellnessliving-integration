<?php

namespace WellnessLiving;

/**
 * @deprecated As of 2023-09-11.
 *
 * Use class {@link \WellnessLiving\Wl\WlHomeTourSid} instead.
 */
class WlHomeTourSid extends \WellnessLiving\Wl\WlHomeTourSid
{
}

?>