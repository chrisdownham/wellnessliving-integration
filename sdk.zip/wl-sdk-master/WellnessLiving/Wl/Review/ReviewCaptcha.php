<?php

namespace WellnessLiving\Wl\Review;

/**
 * Captcha for post review.
 */
class ReviewCaptcha
{
  /**
   * CID of this class.
   */
  const CID = 1066;
}

?>