<?php

namespace WellnessLiving\Wl\Lead;

/**
 * Captcha for "Lead Capture Widget".
 */
class LeadCaptcha
{
  /**
   * CID of this captcha.
   */
  const CID = 1072;
}

?>