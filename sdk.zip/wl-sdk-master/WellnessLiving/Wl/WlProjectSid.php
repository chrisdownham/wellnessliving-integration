<?php

namespace WellnessLiving\Wl;

/**
 * List of different directories, which can use wellnessliving as a source of data.
 */
abstract class WlProjectSid
{
  /**
   * WellnessLiving Explorer.
   */
  const WELLNESSLIVING = 4;
}

?>