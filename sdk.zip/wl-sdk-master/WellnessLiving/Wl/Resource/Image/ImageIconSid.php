<?php

namespace WellnessLiving\Wl\Resource\Image;

/**
 * Predefined icons for assets.
 *
 * Last used ID: 29.
 */
class ImageIconSid
{
  /**
   * Training bench.
   */
  const BENCH = 1;

  /**
   * Exercise bike.
   */
  const BIKE_1 = 2;

  /**
   * Exercise bike.
   */
  const BIKE_2 = 3;

  /**
   * Exercise bike.
   */
  const BIKE_3 = 4;

  /**
   * Exercise bike.
   */
  const BIKE_4 = 5;

  /**
   * Exercise bike.
   */
  const BIKE_5 = 6;

  /**
   * Exercise bike.
   */
  const BIKE_6 = 7;

  /**
   * Boot.
   */
  const BOOT = 8;

  /**
   * Door.
   */
  const DOOR = 9;

  /**
   * Fan.
   */
  const FAN_1 = 10;

  /**
   * Fan.
   */
  const FAN_2 = 11;

  /**
   * Man.
   */
  const MAN = 12;

  /**
   * Mat.
   */
  const MAT = 13;

  /**
   * Mirror.
   */
  const MIRROR = 14;

  /**
   * Orbitrack.
   */
  const ORBITRACK_1 = 15;

  /**
   * Orbitrack.
   */
  const ORBITRACK_2 = 16;

  /**
   * Orbitrack.
   */
  const ORBITRACK_3 = 17;

  /**
   * Orbitrack.
   */
  const ORBITRACK_4 = 18;

  /**
   * Orbitrack.
   */
  const ORBITRACK_5 = 19;

  /**
   * Orbitrack.
   */
  const ORBITRACK_6 = 20;

  /**
   * Boxing punch.
   */
  const PUNCH_1 = 21;

  /**
   * Boxing punch.
   */
  const PUNCH_2 = 22;

  /**
   * Rectangle.
   */
  const RECTANGLE = 23;

  /**
   * Loudspeaker.
   */
  const SPEAKER = 24;

  /**
   * Treadmill.
   */
  const TREADMILL_1 = 25;

  /**
   * Treadmill.
   */
  const TREADMILL_2 = 26;

  /**
   * TV.
   */
  const TV = 27;

  /**
   * Twines.
   */
  const TWINE = 28;

  /**
   * Weight.
   */
  const WEIGHT = 29;
}

?>