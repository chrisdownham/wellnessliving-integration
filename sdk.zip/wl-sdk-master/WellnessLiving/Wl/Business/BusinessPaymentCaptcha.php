<?php

namespace WellnessLiving\Wl\Business;

/**
 * Captcha for payment action.
 */
class BusinessPaymentCaptcha
{
  /**
   * CID of this class.
   */
  const CID = 1064;
}

?>