<?php

namespace WellnessLiving;

/**
 * @deprecated As of 2023-09-11.
 *
 * Use class {@link \WellnessLiving\Wl\WlFacilitySid} instead.
 */
class WlFacilitySid extends \WellnessLiving\Wl\WlFacilitySid
{
}

?>