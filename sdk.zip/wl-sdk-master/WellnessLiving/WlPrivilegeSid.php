<?php

/**
 * @deprecated As of 2023-09-11.
 *
 * Use class {@link \WellnessLiving\Wl\WlPrivilegeSid} instead.
 */
class WlPrivilegeSid extends \WellnessLiving\Wl\WlPrivilegeSid
{
}

?>