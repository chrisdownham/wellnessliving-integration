<?php

namespace WellnessLiving;

use WellnessLiving\Wl\Coupon\PurchaseRestrictionSid;

/**
 * @deprecated As of 2023-09-11.
 *
 * Use class {@link PurchaseRestrictionSid} instead.
 */
class WlPurchaseRestrictionSid extends PurchaseRestrictionSid
{
}

?>