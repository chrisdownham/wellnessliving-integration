<?php

namespace WellnessLiving;

/**
 * @deprecated As of 2023-09-11.
 *
 * Use class {@link \WellnessLiving\Wl\WlProjectSid} instead.
 */
class WlProjectSid extends \WellnessLiving\Wl\WlProjectSid
{
}

?>