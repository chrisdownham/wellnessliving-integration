<?php

namespace WellnessLiving;

/**
 * @deprecated As of 2023-09-11.
 *
 * Use class {@link \WellnessLiving\Wl\WlSaleSid} instead.
 */
abstract class WlSaleSid extends \WellnessLiving\Wl\WlSaleSid
{
}

?>