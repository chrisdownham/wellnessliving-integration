<?php

namespace WellnessLiving;

/**
 * @deprecated As of 2023-09-11.
 *
 * Use class {@link \WellnessLiving\Wl\WlDesignIconSid} instead.
 */
class WlDesignIconSid extends \WellnessLiving\Wl\WlDesignIconSid
{
}

?>